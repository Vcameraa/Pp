# Porichoy Codeigniter 3 / PHP
Identity Verification for Bangladesh Porichoy is the official identity verifications API provider in Bangladesh.
porichoy.gov.bd
